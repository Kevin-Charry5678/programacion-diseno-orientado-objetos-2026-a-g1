package com.corhuila.poo.semana7;

import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {

        List<Envio> envios = new ArrayList<>();

        envios.add(new EnvioEstandar("E001", 2));
        envios.add(new EnvioExpress("E002", 1.5));
        envios.add(new EnvioInternacional("E003", 3, "México"));

        double total = 0;

        for (Envio e : envios) {
            System.out.println(e.resumen());
            total += e.calcularCosto();
        }

        System.out.println("\nTOTAL DEL ENVÍOS: $" + total);
    }
}
