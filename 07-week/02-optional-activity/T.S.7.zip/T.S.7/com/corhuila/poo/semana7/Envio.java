package com.corhuila.poo.semana7;

public class Envio {
    private String codigo;
    private double pesoKg;

    public Envio(String codigo, double pesoKg) {
        setCodigo(codigo);
        setPesoKg(pesoKg);
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(double pesoKg) {
        if (pesoKg <= 0) {
            throw new IllegalArgumentException("El peso debe ser mayor a 0");
        }
        this.pesoKg = pesoKg;
    }

    public double calcularCosto() {
        return 0; // Se sobreescribe en las subclases
    }

    public String resumen() {
        return "Código: " + codigo + " | Peso: " + pesoKg + " kg | Costo: $" + calcularCosto();
    }
}
