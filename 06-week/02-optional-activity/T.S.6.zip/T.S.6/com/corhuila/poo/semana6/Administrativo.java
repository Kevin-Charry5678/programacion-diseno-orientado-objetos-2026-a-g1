package com.corhuila.poo.semana6;

public class Administrativo extends Persona {
    private String cargo;

    public Administrativo(String documento, String nombre, String correo, String cargo) {
        super(documento, nombre, correo);
        setCargo(cargo);
    }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) {
        if (cargo == null || cargo.isEmpty()) {
            throw new IllegalArgumentException("Cargo no puede estar vacío");
        }
        this.cargo = cargo;
    }

    public String fichaAdministrativo() {
        return super.ficha() + "\nCargo: " + cargo;
    }
}
