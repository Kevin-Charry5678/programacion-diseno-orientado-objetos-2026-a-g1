package com.corhuila.poo.semana6;

public class App {
    public static void main(String[] args) {
        Persona p = new Persona("123", "Kevin Charry", "kevin@mail.com");
        Docente d = new Docente("456", "Messi Ronaldo", "messi@mail.com", "Ingeniería");
        Administrativo a = new Administrativo("789", "Ricardo Martines", "ricardo@mail.com", "Secretario");

        System.out.println("=== Persona ===");
        System.out.println(p.ficha());

        System.out.println("\n=== Docente ===");
        System.out.println(d.fichaDocente());

        System.out.println("\n=== Administrativo ===");
        System.out.println(a.fichaAdministrativo());
    }
}
