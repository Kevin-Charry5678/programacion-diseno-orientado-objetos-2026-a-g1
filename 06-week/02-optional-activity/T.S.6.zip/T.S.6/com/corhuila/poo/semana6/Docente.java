package com.corhuila.poo.semana6;

public class Docente extends Persona {
    private String area;

    public Docente(String documento, String nombre, String correo, String area) {
        super(documento, nombre, correo);
        setArea(area);
    }

    public String getArea() { return area; }
    public void setArea(String area) {
        if (area == null || area.isEmpty()) {
            throw new IllegalArgumentException("Área no puede estar vacía");
        }
        this.area = area;
    }

    public String fichaDocente() {
        return super.ficha() + "\nÁrea: " + area;
    }
}
